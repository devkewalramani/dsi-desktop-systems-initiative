<cfquery name="importutica" datasource="dsitest">
SELECT *
FROM utica
</cfquery>

<cfoutput query="importutica">
<cfquery name="addtomaster" datasource="newdsi">
INSERT INTO master (grp,func,lname,fname,wrkhrs,logon,loc,blkberry,status,replacemodel) VALUES ('Financial Services', 'Check','#lname#','#fname#','#wrkhrs#','#logon#','UTICA','#blkberry#','New','GX270')
</cfquery>
#lname#, #fname# - Imported
<br>
</cfoutput>
