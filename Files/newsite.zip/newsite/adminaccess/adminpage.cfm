
<cfquery name="balauth" datasource="newdsi">
SELECT func, pass
FROM functionpass 
Where func='#form.auth#'
</cfquery>
<html><!-- InstanceBegin template="/Templates/dsi.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<!-- InstanceBeginEditable name="doctitle" -->
<title>DSI</title>
<!-- InstanceEndEditable -->
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<!-- InstanceBeginEditable name="head" -->
<style type="text/css">
<!--
.style3 {
	font-size: 10px;
	font-style: italic;
}
-->
</style>
<!-- InstanceEndEditable -->
<link href="../scripts/font.css" rel="stylesheet" type="text/css">

</head>

<body link="#660000" vlink="#660000">
<div id="info" style="position:absolute; left:181px; top:331px; width:224px; height:197px; z-index:1; visibility: hidden;"></div>
<div id="info2" style="position:absolute; left:181px; top:134px; width:224px; height:197px; z-index:1; visibility: hidden;"> 
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr> 
      <td align="center" bgcolor="#cccccc"> 
        <table width="100%" border="0" cellspacing="1" cellpadding="0">
          <tr> 
            <td valign="top" bgcolor="#eeeeee"><div align="center" class="burgundy"><strong>.:: 
                info box ::.</strong></div></td>
          </tr>
          <tr> 
            <td valign="top" bgcolor="#FFFFFF"> 
              <table width="100%" border="0" cellspacing="0" cellpadding="8">
                <tr> 
                  <td valign="top" class="text1">Entering a user id or last name 
                    will allow you to view all tickets. Select the &quot;Open 
                    Tickets&quot; option to view only open tickets. <p>Enter Ticket 
                      No, User ID, or Lastname.</p></td>
                </tr>
              </table>
            </td>
          </tr>
          <tr> 
            <td height="20" bgcolor="#eeeeee"> <div align="center" class="burgundy"><strong>.:<a href="javascript:;" onClick="MM_showHideLayers('info2','','hide')"><img src="../images/close1.jpg" width="100" height="15" border="0"></a>:.</strong></div></td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</div>
<table width="75%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="center" bgcolor="#cccccc"> 
      <table width="100%" border="0" cellspacing="1" cellpadding="0">
        <tr> 
          <td valign="top" bgcolor="#FFFFFF"> 
            <table width="100%" border="0" cellspacing="0" cellpadding="4">
              <tr>
                <td width="65%" align="left" valign="top"><img src="../images/dsilogo.jpg" alt="DSI Logo" width="187" height="67"></td>
              </tr>
            </table></td>
        </tr>
        <tr> 
          <td valign="top" bgcolor="#eeeeee"> <table width="100%" border="0" cellspacing="0" cellpadding="2">
              <tr valign="top"> 
                <td width="1%">&nbsp;</td>
                <td width="48%" class="topmenu"> <script language="JavaScript">

    // -- made by A1javascripts.com, please keep these credits when using this script
    days = new Array(7)
    days[1] = "Sunday";
    days[2] = "Monday";
    days[3] = "Tuesday"; 
    days[4] = "Wednesday";
    days[5] = "Thursday";
    days[6] = "Friday";
    days[7] = "Saturday";
    months = new Array(12)
    months[1] = "January";
    months[2] = "February";
    months[3] = "March";
    months[4] = "April";
    months[5] = "May";
    months[6] = "June";
    months[7] = "July";
    months[8] = "August";
    months[9] = "September";
    months[10] = "October"; 
    months[11] = "November";
    months[12] = "December";
    today = new Date(); day = days[today.getDay() + 1]
    month = months[today.getMonth() + 1]
    date = today.getDate()
    year=today.getYear(); 
if (year < 2000)
year = year + 1900;
    document.write (day +
    ", " + month + " " + date + ", " + year)
    // -- end hiding 
    </script> </td>
                <td width="51%" class="topmenu"><div align="right"><a href="http://www.it.ny.frb.org/wcsd-dsi/">DSI Home </a> 
                    | <a href="http://www.it.ny.frb.org/">IT Website </a>  | <a href="http://atthebank.ny.frb.org/@theBank/currentweek/cover.htm">@TheBank</a> 
                  </div></td>
              </tr>
            </table></td>
        </tr>
        <tr> 
          <td valign="top" bgcolor="#FFFFFF">
<table width="100%" border="0" cellspacing="0" cellpadding="8">
              <tr>
                <td valign="top"><!-- InstanceBeginEditable name="mainbody" -->
<cfoutput query="balauth">
<cfif #form.pass# eq #pass#>
  <table width="100%" cellpadding="3" cellspacing="3" bgcolor="##cccccc">
    <tr bgcolor="##eeeeee">
      <th colspan="3" class="burgundy" scope="col">REPORTS</th>
      </tr>
    <tr bgcolor="##FFFFFF">
      <td><div align="center"><a href="migrationreports.cfm" target="_blank"><strong>MIGRATION REPORTS</strong></a></div></td>
      <td><div align="center"><a href="./reports/index.cfm" target="_blank"><strong>SCHEDULING REPORTS</strong></a> </div></td>
      <td><div align="center"><a href="variance.cfm" target="_blank"><strong>VIEW VARIANCE REPORT </strong></a></div></td>
    </tr>
    <tr bgcolor="##FFFFFF">
      <td><div align="center"><a href="team1reports.cfm" target="_blank"><strong>TEAM 1 REPORTS</strong></a> </div></td>
      <td><div align="center"><a href="team2reports.cfm" target="_blank"><strong>TEAM 2 REPORTS</strong></a> </div></td>
      <td><div align="center"></div></td>
    </tr>
  </table>
  <br>
  <table width="100%"  border="0" cellpadding="3" cellspacing="3" bgcolor="##cccccc">
    <tr bgcolor="##eeeeee">
      <th colspan="3" class="burgundy" scope="col">TOOLS</th>
      </tr>
    <tr bgcolor="##FFFFFF">
      <td><div align="center"><a href="passadmin.cfm" target="_blank"><strong>PASSWORD LOOKUP </strong></a></div></td>
      <td><div align="center"><a href="search.cfm" target="_blank"><strong>CUSTOMER SEARCH UPDATE / EDIT</strong></a></div></td>
      <td><div align="center"><strong class="burgundy"><a href="functionlimit.cfm" target="_blank">SET DAILY FUNCTION LIMIT</a> </strong></div></td>
    </tr>
    <tr bgcolor="##FFFFFF">
      <td bgcolor="##FFFFFF"><div align="center" class="burgundy"><a href="grpdevicecount.cfm" target="_blank"><strong>EDIT GROUP DEVICE COUNT</strong></a><strong> </strong></div></td>
      <td><div align="center"><strong><a href="scheduledmigrations.cfm" target="_blank">CAPTURE VARIANCE DATA </a><br>
              <span class="style3">For Glen Radziminski only </span></strong></div></td>
      <td><div align="center" class="burgundy"><a href="wschedule.cfm" target="_blank"><strong>VIEW WEEKLY SCHEDULES</strong></a></div></td>
    </tr>
    <tr bgcolor="##FFFFFF">
      <td><div align="center" class="burgundy"><a href="addnewcust.cfm"><strong>ADD NEW CUSTOMER</strong></a><strong> </strong></div></td>
      <td><div align="center"><span class="burgundy"><strong><a href="deletesearch.cfm" target="_blank">DELETE CUSTOMER</a></strong></span></div></td>
      <td><div align="center" class="burgundy"><strong><a href="search2.cfm" target="_blank">RE-ASSIGN ASSET</a></strong> </div></td>
    </tr>
    <tr bgcolor="##FFFFFF">
      <td bgcolor="##FFFFFF"><div align="center"><strong class="burgundy"><a href="grantaccess.cfm" target="_blank">FUNCTION ACCESS LEVEL</a></strong></div></td>
      <td><div align="center"><a href="balemail.cfm" target="_blank"><strong class="burgundy">BAL EMAIL LIST </strong></a><strong class="burgundy"></strong></div></td>
      <td><div align="center" class="burgundy"><strong><a href="times/index.cfm" target="_blank">EDIT FUNCTION TIME SLOTS</a> </strong></div></td>
    </tr>
    <tr bgcolor="##FFFFFF">
      <td bgcolor="##FFFFFF"><div align="center" class="burgundy"><a href="../team2/cancel.cfm"><strong>CANCEL MIGRATION</strong></a><strong> </strong></div></td>
      <td><div align="center"><a href="../nacs/search.cfm"><strong>EDIT LOGON/CONTEXT</strong></a></div></td>
      <td>&nbsp;</td>
    </tr>
  </table>
  <br>
<cfelseif #form.pass# neq #pass#>
<meta http-equiv="refresh" content="0;URL=./adminaccess.cfm?error=1">
</cfif>
</cfoutput>
<!-- InstanceEndEditable --></td>
              </tr>
            </table> </td>
        </tr>
        <tr> 
          <td valign="top" bgcolor="#FFFFFF">&nbsp;</td>
        </tr>
        <tr> 
          <td valign="top" bgcolor="#999999"><font color="#FFFFFF">This site optimally 
            viewed with Internet Explorer running on Windows 2000 or higher.</font></td>
        </tr>
      </table></td>
  </tr>
</table>
<map name="Map">
              <area shape="rect" coords="19,2,151,48" href="http://www.it.ny.frb.org/wcsd-dsi">
</map>
</body>
<!-- InstanceEnd --></html>
